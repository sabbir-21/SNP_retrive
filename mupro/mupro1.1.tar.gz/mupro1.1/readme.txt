#################################################################################
#MUpro: predict the stability of single-site mutations from protein
#       sequences using support vector machines
#
#References:
#
#For the method:
#J. Cheng, A. Randall, and P. Baldi. Prediction of Protein Stability Changes
#for Single Site Mutations Using Support Vector Machines. Proteins: Structure,
#Function, Bioinformatics, vol. 62, no. 4, pp. 1125-1132, 2006.
#
#For the web server:
#J. Cheng, A. Z. Randall, M. Sweredoski, and P. Baldi. SCRATCH: a Protein 
#Structure and Structural Feature Prediction Server. Nucleic Acids Research, 
#vol. 33 (server issue), w72-76, 2005.
#
#Contact: 
#Jianlin Cheng
#Ph.D. Candidate
#Insititue for Genomics and Bioinformatics
#School of Information and Computer Sciences
#University of California Irvine
#Email: jianlinc@ics.uci.edu
#
#Copyright:  Free for academic/scientific use.
#
#################################################################################

I. Installation (Linux version)

	1. MUpro uses the classification executable of SVM-light. Please first download
	   SVM-light 6.01 Linux binary from http://svmlight.joachims.org/. Unzip the SVM-light 
           package to some place.
	   You need to copy the "svm_classify" file of SVM-light into the sub 
	   directory of MUpro later.

	2. Unzip mupro1.0.tar.gz and change into mupro1.0
		e.g. 
		     tar xzf mupro1.0.tar.gz
		     cd mupro1.0

	3. copy svm_classify from svm-light dir into server sub directory of mupro1.0. 
	        e.g.
	             cp /.../svm_classify  ./server


	4. open configure.pl, set install_dir to the installation dir of
           mupro. 
	   	e.g.
	   	     $install_dir = "/home/.../mupro1.0";

	5. run configure.pl to configure the system.
		e.g.
		     ./configure.pl

	Installation is done.

II. Testing the system

	In the test dir, execute the following two scripts:

        a) regression: predict the real values of energy changes.

           ../bin/predict_regr.sh test1  

	   Results should be the same as regr1.  

	b) classification: predict if a mutation increases or decreases the
	   stability.

	   ../bin/predict_class.sh test1  

           Results should be the same as class1. 

	   You can make the similar tests on test2, ..., test5. 

	c) regression on all 19 possible mutations: predict energy changes
           for all possible mutations.
	  
           ../bin/predict_regr_all.sh test_all3
           The output should be the same as regr_all3. 

III. Descriptions of usage

     In the bin directory, three scripts: predict_regr.sh and
     predict_class.sh, predict_class_small.sh are used to predict mutation stability.

     predict_regr.sh: predict the value of the energy change (delta delta G).
     	positive value: increase stability. negative value: decrease stability.

     predict_regr_all.sh: predict the value of the energy change (delta delta G)
        for all 19 possible mutations.
     	positive value: increase stability. negative value: decrease stability.

     predict_class.sh: predict if a mutation increases or decrease
     	the stability with a confidence score(>0: increase, <0: decrease).
        This confidence score is not energy score. 

     predict_class_small.sh: predict if a mutation increases or decrease
     	the stability with a confidence score(>0: increase, <0: decrease).
        This confidence score is not energy score.
	This script use a smaller sequence window.

     
     Usage:   script   input_file

     input_file format:
     	line1: name
	line2: sequence
	line3: mutation position
	line4: original residue
	line5: substitute residue

      Output to the standard output:
         Effects of mutation; confidence scores or real values of energy changes.

      For an input file example, see test1  in test dir.

      For an output example, see class1 or regr1 in test dir.

      Notice:
         To predict mutation stability changes for all 19 possible mutations, 
         please use predict_regr_all.sh and set the substitute residue to * in 
         the input file.

IV. Disclaimer

    This software is free only for non-commercial use. It must not be distributed
    without prior permission of the author. The author is not responsible for
    implications from the use of this software. 

    You feedback is very valuable for improving the software. Please email your
    questions or suggestions to jianlinc@ics.uci.edu.  Thanks.

V. Release notes:

   Version 1.1: add script predict_regr_all.sh to predict mutation energy
   changes for all 19 possible mutations for a position. 
   Added by Denis C. Bauer (The University of Queensland,
   Brisbane, Australia) and Jianlin Cheng.
   2/25/2005.

   Fix typos in readme file. I'd like to thank Denis Bauer for pointing out 
   the problems. 2/25/2006. 
   
   Version 1.0: 9/17/2005.

